<?php

function closetags($html) {
    preg_match_all('#<(?!meta|img|br|hr|input\b)\b([a-z]+)(?: .*)?(?<![/|/ ])>#iU', $html, $result);
    $openedtags = $result[1];
    preg_match_all('#</([a-z]+)>#iU', $html, $result);
    $closedtags = $result[1];
    $len_opened = count($openedtags);
    if (count($closedtags) == $len_opened) {
        return $html;
    }
    $openedtags = array_reverse($openedtags);
    for ($i=0; $i < $len_opened; $i++) {
        if (!in_array($openedtags[$i], $closedtags)) {
            $html .= '</'.$openedtags[$i].'>';
        } else {
            unset($closedtags[array_search($openedtags[$i], $closedtags)]);
        }
    }
    return $html;
} 
?>

<section class="edu_page_title_wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 text-center">
                <div class="edu_page_title_text">
                    <h1>Blog Page</h1>
                    <ul>
                        <li><a href="http://192.168.0.5/e-academy/">Home</a></li>
                        <li><a href="javascript:void(0);">Blog</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

       <!--   <section class="edu_sglblog_wrapper">
    <div class="container">
        <div class="row">            
            <div class="col-lg-8 col-md-12 col-sm-12 col-12">
                <div class="edu_sglblog_section">
				<?php if(!empty($blog)){ 
						foreach($blog as $value){
							
							$added_by = $this->db_model->select_data('*','users',array('id'=>$value['added_by']),1);
							$comments = count($this->db_model->select_data('*','blog_comments',array('blog_id'=>$value['id'])));
					?>
                    <div class="edu_sglblog_inner bgshadowradios mb_30">
                        <img src="<?php echo base_url('/uploads/blog/').$value['image'] ; ?>" alt="image">
                        <a href="<?php echo base_url('/blog/').$value['id']; ?>" class="edu_sglblog_title"><?php if(!empty($value['title'])){ echo $value['title'] ; } ?></a>
                        <ul class="sglblog_metapost">
                            <li>
                                <a href="<?php echo base_url('/blog/').$value['id']; ?>"> <i class="fas fa-user"></i> <?php if(!empty($added_by)){ echo $added_by[0]['name'] ; } ?></a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('/blog/').$value['id']; ?>"> <i class="fas fa-calendar-alt"></i> <?php echo date('d-m-Y',strtotime($value['create_at'])) ; ?></a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('/blog/').$value['id']; ?>"> <i class="fas fa-comments"></i> <?php echo $comments.' '.html_escape($this->common->languageTranslator('ltr_comments')) ; ?></a>
                            </li>
                        </ul>
                        <p class="edu_sglblog_des mb_30"><?php if(!empty($value['description'])){ if(strlen($value['description'])<250){ echo  closetags(html_entity_decode(substr($value['description'], 0, 250)),ENT_QUOTES, 'UTF-8') ;}else{ echo  closetags(html_entity_decode(substr($value['description'], 0, 250)),ENT_QUOTES, 'UTF-8'); ?> <a href="<?php echo base_url('/blog/').$value['id']; ?>"><?php echo html_escape($this->common->languageTranslator('ltr_read_more'));?> </a> <?php } } ?></p>
                    </div>
					<?php }
						}else{
							echo html_escape($this->common->languageTranslator('ltr_no_blog'));
							} ?>
				</div>		
            </div>
                  </div>
            </div>
    
</section> -->


					

<section class="edu_sglblog_wrapper">
    <div class="container" style="padding: 33px;" data-aos="fade-up" data-aos-delay="100">
        <!-- Category Dropdown Section -->
        <div class="row">
    <div class="col-md-12">
        <div class="edu-select-category">
            <select id="blogcategory_dropdown" class="form-control">
                <option value="all">All Categories</option>
                
                <?php foreach ($category_data as $cat) { ?>
                    <option value="<?php echo htmlspecialchars($cat['id']); ?>">
                        <?php echo htmlspecialchars($cat['name']); ?>
                    </option>
                <?php } ?>
                
                <option value="other">Other</option>
                
            </select>
            <div id="blogsubcategory_dropdown" class="dropdown-menu">
                <!-- Subcategories will be populated here dynamically -->
            </div>
        </div>
    </div>
</div>

        <!-- Blog Section -->
        <div class="row mt-4">
            <?php if (!empty($blog)) {
                foreach ($blog as $value) {
                    // Fetch additional data
                    $added_by = $this->db_model->select_data('*', 'users', array('id' => $value['added_by']), 1);
                    $comments = count($this->db_model->select_data('*', 'blog_comments', array('blog_id' => $value['id'])));
            ?>
            <div class="col-lg-4 mb-4">
                <div class="h-100" style="box-shadow: 0 0px 8px rgba(0, 0, 0, 0.2);">
                    <img src="<?php echo base_url('/uploads/blog/') . $value['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($value['title']); ?>" style="height: 250px;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3">
                            <div style="color: #1b1c25 !important; font-size: 14px;">
                                <span><?php echo htmlspecialchars($value['category']); ?></span>
                            </div>
                           <div style="color: #1b1c25 !important; font-size: 14px;text-align: left;">
                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#5f6368">
                                    <path d="M200-80q-33 0-56.5-23.5T120-160v-560q0-33 23.5-56.5T200-800h40v-80h80v80h320v-80h80v80h40q33 0 56.5 23.5T840-720v560q0 33-23.5 56.5T760-80H200Zm0-80h560v-400H200v400Zm0-480h560v-80H200v80Zm0 0v-80 80Zm280 240q-17 0-28.5-11.5T440-440q0-17 11.5-28.5T480-480q17 0 28.5 11.5T520-440q0 17-11.5 28.5T480-400Zm-160 0q-17 0-28.5-11.5T280-440q0-17 11.5-28.5T320-480q17 0 28.5 11.5T360-440q0 17-11.5 28.5T320-400Zm320 0q-17 0-28.5-11.5T600-440q0-17 11.5-28.5T640-480q17 0 28.5 11.5T680-440q0 17-11.5 28.5T640-400ZM480-240q-17 0-28.5-11.5T440-280q0-17 11.5-28.5T480-320q17 0 28.5 11.5T520-280q0 17-11.5 28.5T480-240Zm-160 0q-17 0-28.5-11.5T280-280q0-17 11.5-28.5T320-320q17 0 28.5 11.5T360-280q0 17-11.5 28.5T320-240Zm320 0q-17 0-28.5-11.5T600-280q0-17 11.5-28.5T640-320q17 0 28.5 11.5T680-280q0 17-11.5 28.5T640-240Z" />
                                </svg>
                                <span class="mt-1"><?php echo date('d-m-Y', strtotime($value['create_at'])); ?></span>
                            </div>
                        </div>
                        <h5 class="card-title" style="color: inherit;"><?php echo htmlspecialchars($value['title']); ?></h5>
                        <p class="card-text">
                            <?php
                                $description = html_entity_decode($value['description']);
                                echo (strlen($description) < 150) ? $description : substr($description, 0, 150) . '...';
                            ?>
                        </p>
                        <a href="<?php echo base_url('/blog/') . $value['id']; ?>" class="readmore">
                            <?php echo 'View Blog Details'; ?>
                        </a>
                    </div>
                </div>
            </div>
            <?php 
                }
            } else {
                echo '<p>' . html_escape($this->common->languageTranslator('ltr_no_blog')) . '</p>';
            } ?>
        </div>
    </div>
</section>


        <!--    <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                <div class="sglblog_sidebar">
                    <!--<div class="edu_sglblog_search bgshadowradios mb_30">
                        <form class="bs_search_form">
                            <input type="search" class="bs_search_field" placeholder="Search" value="" name="s">
                            <button type="submit" class="bs_search_submit">
                            <i class="fa fa-search" aria-hidden="true"></i>
                            </button>
                        </form>
                    </div> -->
              <!--      <div class="sglblog_recent bgshadowradios mb_30">
                        <h4 class="edu_cmntitle mb_30"><?php echo html_escape($this->common->languageTranslator('ltr_blog_recent'));?></h4>
                        <ul class="blog_recent_list">
						  <?php if(!empty($recent_blog)){ 
						  foreach($recent_blog as $rvalue){ ?>
                            <li>
                                <div class="blog_thumb">
                                    <a href="<?php echo base_url('/blog/').$rvalue['id']; ?>" >
                                        <img src="<?php echo base_url('/uploads/blog/').$rvalue['image'] ; ?>" alt="image" class="img-fluid">
                                    </a>
                                </div>
                                <div class="blog_content">
                                    <a href="<?php echo base_url('/blog/').$rvalue['id']; ?>"><?php if(!empty($value['title'])){ echo substr(strip_tags($rvalue['title']), 0, 50) ; } ?></a>
                                    <span><?php echo date('d-m-Y',strtotime($rvalue['create_at'])) ; ?></span>
                                </div>
                            </li>
						  <?php 
								}
							 }else{
								echo html_escape($this->common->languageTranslator('ltr_no_blog'));
							} ?>
                    
                        </ul>
                    </div> -->
					<!-- <div class="sglblog_recent bgshadowradios mb_30">
                        <h4 class="edu_cmntitle mb_30"><?php echo html_escape($this->common->languageTranslator('ltr_blog_news'));?></h4>
                        <ul class="blog_recent_list">
						  <?php if(!empty($recent_blog)){ 
						  foreach($recent_blog as $rvalue){ ?>
                            <li>
                                <div class="blog_thumb">
                                    <a href="<?php echo base_url('/blog/').$rvalue['id']; ?>" >
                                        <img src="<?php echo base_url('/uploads/blog/').$rvalue['image'] ; ?>" alt="image" class="img-fluid">
                                    </a>
                                </div>
                                <div class="blog_content">
                                    <a href="<?php echo base_url('/blog/').$rvalue['id']; ?>"><?php if(!empty($value['title'])){ echo substr(strip_tags($rvalue['title']), 0, 50)  ; } ?></a>
                                    <span><?php echo date('d-m-Y',strtotime($rvalue['create_at'])) ; ?></span>
                                </div>
                            </li>
						  <?php 
								}
							 }else{
								echo html_escape($this->common->languageTranslator('ltr_no_news'));
							} ?>
                    
                        </ul>
                    </div> -->
                    <!-- <div class="sglblog_archive bgshadowradios mb_30">
                        <h4 class="edu_cmntitle mb_30"><?php echo html_escape($this->common->languageTranslator('ltr_archives'));?></h4>
                        <ul class="blog_archive_list">
                            <li>
                            <a href="">
                                <span> <i class="fa fa-caret-right" aria-hidden="true"></i> January</span>
                                <span>2021</span>
                            </a>                            
                            </li>
                            <li>
                            <a href="">
                                <span> <i class="fa fa-caret-right" aria-hidden="true"></i> Fabuary</span>
                                <span>2022</span>
                            </a>                            
                            </li>
                            <li>
                            <a href="">
                                <span> <i class="fa fa-caret-right" aria-hidden="true"></i> March</span>
                                <span>2019</span>
                            </a>                            
                            </li>
                            <li>
                            <a href="">
                                <span> <i class="fa fa-caret-right" aria-hidden="true"></i> May</span>
                                <span>2018</span>
                            </a>                            
                            </li>
                            <li>
                            <a href="">
                                <span> <i class="fa fa-caret-right" aria-hidden="true"></i> April</span>
                                <span>2017</span>
                            </a>                            
                            </li>
                        </ul>
                    </div> -->
            <!--       <div class="sglblog_glry bgshadowradios mb_30">
                        <h4 class="edu_cmntitle mb_30"><?php echo html_escape($this->common->languageTranslator('ltr_gallery'));?></h4>
                        <ul class="blog_glry_list">
						    <?php if(!empty($gallery)){ 
							foreach($gallery as $gvalue){?>
                            <li><a href="<?php echo base_url('gallery'); ?>"> <img src="<?php echo base_url('uploads/gallery/').$gvalue['image'] ;?>" alt="image"></a></li>
							<?php } }else{
								echo html_escape($this->common->languageTranslator('ltr_no_image'));
							} ?> 
                        </ul>
                    </div> -->
          
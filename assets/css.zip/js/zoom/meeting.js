window.addEventListener('DOMContentLoaded', function(event) {
  websdkready();
});
// ZoomMtg.preLoadWasm();
function websdkready() {
  var testTool = window.testTool;
  // get meeting args from url
    var tmpArgs = testTool.parseQuery();
    var SDK_key = document.getElementById('SDK_key').value;
    var SDK_secret = document.getElementById('SDK_secret').value;
    
    var meetingNumber= parseInt(document.getElementById('meeting_number').value);
    var username= document.getElementById('display_name').value;
    var passWord= document.getElementById('meeting_pwd').value;
    var leave_Url= document.getElementById('leaveurl').value;
    var signature_= document.getElementById('signature').value;
    var lang = 'en-US';
    var userEmail = "";
    var webEndpoint = "";
    var china = "1";
    var tmpArgs = testTool.parseQuery();
    var meetingConfig = {
    sdkKey: SDK_key,
    meetingNumber: meetingNumber,
    userName: (function () {
      if (username) {
        try {
          return testTool.b64DecodeUnicode(tmpArgs.username);
        } catch (e) {
          return tmpArgs.username;
        }
      }
      return (
        "CDN#" +
        tmpArgs.version +
        "#" +
        testTool.detectOS() +
        "#" +
        testTool.getBrowserInfo()
      );
    })(),
    passWord: passWord,
    leaveUrl: leave_Url,
    role: 1,
    userEmail: (function () {
      try {
        return testTool.b64DecodeUnicode(userEmail);
      } catch (e) {
        return userEmail;
      }
    })(),
    lang: lang,
    signature:  signature_|| "",
    china: china === "1",
    };

  
  // a tool use debug mobile device
  if (testTool.isMobileDevice()) {
    vConsole = new VConsole();
  }
   //console.log(JSON.stringify(ZoomMtg.checkSystemRequirements()));

  // it's option if you want to change the WebSDK dependency link resources. setZoomJSLib must be run at first
 // if (meetingConfig.china){
 //   ZoomMtg.setZoomJSLib("https://jssdk.zoomus.cn/2.16.0/lib", "/av"); // china cdn option
 // }else{
    ZoomMtg.setZoomJSLib("https://source.zoom.us/2.16.0/lib", "/av"); // CDN version defaul
  //}
  ZoomMtg.preLoadWasm();
  ZoomMtg.prepareJssdk();
  function beginJoin(signature) {
    ZoomMtg.init({
      leaveUrl: meetingConfig.leaveUrl,
      webEndpoint: meetingConfig.webEndpoint,
      disableCORP: !window.crossOriginIsolated, // default true
      // disablePreview: false, // default false
      externalLinkPage: './externalLinkPage.html',
      success: function () {
        console.log('zooom '+signature);
        // console.log("signature", signature);
        ZoomMtg.i18n.load(meetingConfig.lang);
        ZoomMtg.i18n.reload(meetingConfig.lang);
        ZoomMtg.join({
          meetingNumber: meetingConfig.meetingNumber,
          userName: username,
          signature:signature,
          sdkKey: meetingConfig.sdkKey,
          userEmail: meetingConfig.userEmail,
          passWord: meetingConfig.passWord,
          success: function (res) {
            console.log("join meeting success");
            // console.log("get attendeelist");
            ZoomMtg.getAttendeeslist({});
            ZoomMtg.getCurrentUser({
              success: function (res) {
                // console.log("success getCurrentUser", res.result.currentUser);
              },
            });
          },
          error: function (res) {
            console.log('zoom1 '+res);
          },
        });
      },
      error: function (res) {
        console.log('zoom2 '+res);
      },
    });

    ZoomMtg.inMeetingServiceListener('onUserJoin', function (data) {
      console.log('inMeetingServiceListener onUserJoin', data);
    });
  
    ZoomMtg.inMeetingServiceListener('onUserLeave', function (data) {
      console.log('inMeetingServiceListener onUserLeave', data);
    });
  
    ZoomMtg.inMeetingServiceListener('onUserIsInWaitingRoom', function (data) {
      console.log('inMeetingServiceListener onUserIsInWaitingRoom', data);
    });
  
    ZoomMtg.inMeetingServiceListener('onMeetingStatus', function (data) {
      console.log('inMeetingServiceListener onMeetingStatus', data);
    });
  }

  beginJoin( signature_);
};
